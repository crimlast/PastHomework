//
//	Name:		Barrientos, Joshua
//	Homework:	1
//	Due:		2/11/20
//	Course:		cs-2400-01
//
//	Description:
//			Creation of an ArrayBag class that implements the BagInterface.
//

public class ArrayBag<T> implements BagInterface<T>{
	private T[] bag;
	private static final int Capacity = 6;
	private int numberOfEntries;
	@SuppressWarnings("unchecked")
	public ArrayBag() {
		T[] tempBag = (T[])new Object[Capacity];
		numberOfEntries = 0;
		bag = tempBag;
	}
	public int getCurrentSize(){
		return numberOfEntries;
	}
	public boolean isEmpty(){
		return numberOfEntries == 0;
	}
	public boolean add(T newEntry){
		if (numberOfEntries == 6){
			return false;
		}
		else{
			bag[numberOfEntries] = newEntry;
			numberOfEntries++;
			return true;
		}
	}

	public T remove(){
		T theEntry = bag[numberOfEntries - 1];
		bag[numberOfEntries - 1] = null;
		numberOfEntries--;
		return theEntry;
	}
	public boolean contains(T entry){
		for(int i = 0; i < numberOfEntries; i++){
			if(bag[i] == entry){
				T temp = bag[i];
				bag[i] = bag[numberOfEntries - 1];
				bag[numberOfEntries - 1] = temp;
				return true;
			}
		}
		return false;
	}
}





