//
//	Name:		Barrrientos, Joshua
//	Homework:	1
//	Due:		2/12/20
//	Course:		cs-2400-01
//	Description: Code  that will create a Bag interface.
//
public interface BagInterface<T>{
	public int getCurrentSize();
	public boolean isEmpty();
	public boolean add(T newEntry);
	public T remove();
	public boolean contains(T anEntry);
}
